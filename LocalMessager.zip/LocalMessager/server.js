const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const fs = require('fs');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

// Xabarlar tarixini saqlash uchun JSON fayl
const chatHistoryFile = './public/data.json';

// Onlayn foydalanuvchilar ro'yxati
let users = [];

// Xabarlar tarixini JSON faylidan olish
function loadChatHistory() {
  if (fs.existsSync(chatHistoryFile)) {
    const data = fs.readFileSync(chatHistoryFile, 'utf8');
    return JSON.parse(data);
  }
  return [];
}

// Xabarlar tarixini JSON faylga saqlash
function saveChatHistory(history) {
  fs.writeFileSync(chatHistoryFile, JSON.stringify(history, null, 2));
}

io.on('connection', (socket) => {
  console.log('Foydalanuvchi ulandi: ' + socket.id);

  // Foydalanuvchi yangi qo'shilganda ismi bilan tanishamiz
  socket.on('new-user', (username) => {
    // Yangi foydalanuvchini ro'yxatga qo'shamiz
    users.push({ id: socket.id, username });
    io.emit('user-list', users.map(user => user.username)); // Foydalanuvchilar ro'yxatini barcha foydalanuvchilarga yuborish

    // Yangi foydalanuvchiga chat tarixini yuborish
    const history = loadChatHistory();
    socket.emit('chat-history', history);
  });

  // Xabar yuborilganda
  socket.on('chat-message', (data) => {
    // Xabarni saqlash
    const history = loadChatHistory();
    history.push(data);
    saveChatHistory(history);

    // Barcha foydalanuvchilarga xabarni yuborish
    io.emit('chat-message', data);
  });

  // Foydalanuvchi chiqib ketganda ro'yxatdan o'chirish
  socket.on('disconnect', () => {
    console.log('Foydalanuvchi o‘chdi: ' + socket.id);
    users = users.filter(user => user.id !== socket.id); // Foydalanuvchini ro'yxatdan o'chirish
    io.emit('user-list', users.map(user => user.username)); // Yangilangan foydalanuvchilar ro'yxatini yuborish
  });
});

server.listen(3000, () => {
  console.log('Server 3000 portida ishga tushdi');
});
