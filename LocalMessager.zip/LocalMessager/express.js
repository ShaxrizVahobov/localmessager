const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const fs = require('fs');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

app.use(express.static('public'));

let users = {}; // Foydalanuvchilarni saqlaymiz
const chatHistoryFile = 'chat-history.json';

function loadChatHistory() {
  if (fs.existsSync(chatHistoryFile)) {
    const data = fs.readFileSync(chatHistoryFile, 'utf8');
    return JSON.parse(data);
  }
  return [];
}

function saveChatHistory(history) {
  fs.writeFileSync(chatHistoryFile, JSON.stringify(history, null, 2));
}

// Foydalanuvchilar ro'yxatini yaratish uchun funksiyamiz
function getUserList() {
  return Object.values(users).map((user) => ({
    name: user.username,
    isOnline: user.isOnline,
  }));
}

io.on('connection', (socket) => {
  socket.on('new-user', (username) => {
    users[socket.id] = { username, isOnline: true };
    io.emit('user-list', getUserList());

    const history = loadChatHistory();
    socket.emit('chat-history', history);
  });

  socket.on('chat-message', (data) => {
    const history = loadChatHistory();
    history.push(data);
    saveChatHistory(history);

    io.emit('chat-message', data);
  });

  socket.on('disconnect', () => {
    if (users[socket.id]) {
      users[socket.id].isOnline = false;
      io.emit('user-list', getUserList());
    }
  });
});

server.listen(3000, () => {
  console.log('Server 3000 portida ishga tushdi');
});
