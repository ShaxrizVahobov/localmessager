const socket = io();

let username = localStorage.getItem('username');
if (!username) {
  username = prompt("Ismingizni kiriting:");
  if (username) {
    localStorage.setItem('username', username);
  }
}

if (username) {
  socket.emit('new-user', username);
}

socket.on('user-list', (users) => {
  const userList = document.getElementById('users');

  users.forEach((user) => {
    let li = document.getElementById(`user-${user.name}`);

    // Agar foydalanuvchi allaqachon ro'yxatda mavjud bo'lsa, uning holatini yangilaymiz
    if (li) {
      li.classList.remove('online', 'offline');
      li.classList.add(user.isOnline ? 'online' : 'offline');
    } else {
      // Yangi foydalanuvchini qo'shish
      li = document.createElement('li');
      li.id = `user-${user.name}`;
      li.textContent = user.name;
      
      const onlineDot = document.createElement('span');
      onlineDot.classList.add('online-dot');
      li.appendChild(onlineDot);
      
      li.classList.add(user.isOnline ? 'online' : 'offline');
      userList.appendChild(li);
    }
  });
});
